import java.util.*;
public class avenger
{
	Scanner obj=new Scanner(System.in);
	public String name,weapon,planet;
	public int age,power;
	void getDetails() 
	{
		System.out.println("enter the avenger details");
		System.out.println("enter the name");
		name=obj.nextLine();
		System.out.println("enter the age");
		age=obj.nextInt();
		System.out.println("enter the weapon");
		weapon=obj.nextLine();
		System.out.println("enter the planet");
		planet=obj.nextLine();
		System.out.println("enter the power");
		power=obj.nextInt();
	}
	void displayDetails()
	{
		System.out.println("AVENGER DETAILS");
		System.out.println("name : "+name);
		System.out.println("age : "+age);
		System.out.println("weapon : "+weapon);
		System.out.println("planet : "+planet);
		System.out.println("power : "+power);
	}
	public static void main(String args[])
	{
		avenger[] a=new avenger[5];
		for(int i=0;i<5;i++)
		{
			a[i].getDetails();
			a[i].displayDetails();
		}
	}

}