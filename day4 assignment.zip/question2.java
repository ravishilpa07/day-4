import java.util.*;
public class question2 
{
	Scanner obj=new Scanner(System.in);
	public int[] a=new int[5];
	public void details()
	{
		System.out.println("eneter the any 5 numbers");
		for (int i=0;i<5;i++)
		{
			a[i]=obj.nextInt();
		}
	}
	public void displayoddnumbers()
	{
		System.out.println("odd numbers entered by user is :");
		for(int i=0;i<5;i++)
		{
			if(a[i]%2==1)
			{
				System.out.println(a[i]);
			}
		}
	}
	

	public static void main(String[] args) 
	{
		
		question2 q=new question2();
		q.details();
		q.displayoddnumbers();

	}

}
