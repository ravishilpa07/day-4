import java.util.*;
public class question3 
{
	Scanner obj=new Scanner(System.in);
	int a[]=new int[5];
	public void details() 
	{
		System.out.println("enter any 5 numbers");
		for(int i=0;i<5;i++)
		{
			a[i]=obj.nextInt();
		}
	}
	public void sum()
	{
		int sum=0;
		for(int i=0;i<5;i++)
		{
			sum=sum+a[i];
		}
		System.out.println("sum : "+sum);
	}

	public static void main(String[] args)
	{
		question3 q=new question3();
		q.details();
		q.sum();
		
	}

}
